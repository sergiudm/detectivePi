#from .server import handle_client
from .mailbot import send_email

__all__ = ["handle_client", "send_email"]